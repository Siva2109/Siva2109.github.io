import sys, xbmcplugin, xbmcgui, xbmcaddon, xbmc, requests
from bs4 import BeautifulSoup
from urllib.parse import urlencode, parse_qs

ADDON = xbmcaddon.Addon()
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[StayCoolFelix] {msg}", level)

def build_url(query):
    return BASE_URL + '?' + urlencode(query)

def get_html(url):
    try:
        log(f"Fetching URL: {url}")
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.text
    except Exception as e:
        log(f"Error fetching {url}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return None

def list_home():
    xbmcplugin.setPluginCategory(HANDLE, "TamilGun")
    xbmcplugin.setContent(HANDLE, "videos")
    
    url = "https://tamilgun.group/"
    html = get_html(url)
    if not html:
        return
    soup = BeautifulSoup(html, "html.parser")
    
    for show in soup.select("div.title a"):
        show_title = show.get_text(strip=True)
        show_url = show["href"]
        url = build_url({"action": "list_episodes", "show_url": show_url})
        li = xbmcgui.ListItem(label=show_title)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(show_url):
    html = get_html(show_url)
    if not html:
        return
    soup = BeautifulSoup(html, "html.parser")
    for ep in soup.select("article a"):
        ep_title = ep.get_text(strip=True)
        ep_url = ep["href"]
        url = build_url({"action": "play", "video_url": ep_url})
        li = xbmcgui.ListItem(label=ep_title)
        li.setInfo('video', {'title': ep_title})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(video_url):
    html = get_html(video_url)
    if not html:
        return
    soup = BeautifulSoup(html, "html.parser")
    stream_url = None
    video_tag = soup.find("video")
    if video_tag and video_tag.find("source"):
        stream_url = video_tag.find("source")["src"]
    if not stream_url:
        iframe = soup.find("iframe")
        if iframe:
            stream_url = iframe["src"]
    if not stream_url:
        xbmcgui.Dialog().notification("Error", "Stream URL not found", xbmcgui.NOTIFICATION_ERROR)
        log(f"Stream URL not found in {video_url}", xbmc.LOGERROR)
        return
    li = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

def router(paramstring):
    params = dict(parse_qs(paramstring))
    action = params.get("action", [None])[0]
    if action is None:
        list_home()
    elif action == "list_episodes":
        list_episodes(params["show_url"][0])
    elif action == "play":
        play_video(params["video_url"][0])
    else:
        list_home()

if __name__ == "__main__":
    router(sys.argv[2][1:])
