import sys
import urllib.parse
import xbmcgui
import xbmcplugin

# Get the handle for the plugin
HANDLE = int(sys.argv[1])

def build_menu():
    # This is where we will add your movie sites later
    # Example: List a 'Latest Movies' category
    add_directory_item("Latest Movies", "latest_movies")
    
    xbmcplugin.endOfDirectory(HANDLE)

def add_directory_item(name, action):
    # This helper function adds a clickable folder to the Kodi menu
    url = f"{sys.argv[0]}?action={action}"
    list_item = xbmcgui.ListItem(label=name)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)

if __name__ == '__main__':
    # Get parameters from Kodi
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')

    if not action:
        # If no action, show the main menu
        build_menu()
    elif action == 'latest_movies':
        # This is where the scraper logic will go next!
        xbmcgui.Dialog().ok("SivaDelight", "Scraper logic coming soon!")
