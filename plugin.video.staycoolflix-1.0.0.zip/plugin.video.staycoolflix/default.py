import xbmcplugin, xbmcgui, xbmcaddon, sys

addon_handle = int(sys.argv[1])
xbmcgui.Dialog().notification("StayCoolFlix", "Welcome to StayCoolFlix!", xbmcgui.NOTIFICATION_INFO, 5000)
