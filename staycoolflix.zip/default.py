# StayCoolFlix - default.py
# Lightweight Kodi plugin demo (Python 3 / Kodi 18+ compatible)
from urllib.parse import parse_qs, urlencode
import sys, xbmcgui, xbmcplugin, xbmcaddon

_addon = xbmcaddon.Addon()
_handle = int(sys.argv[1])
_base_url = sys.argv[0]

def build_url(query):
    return _base_url + '?' + urlencode(query)

def list_root():
    items = [
        {'label': 'Live TV (placeholder)', 'path': build_url({'mode':'play', 'url':'plugin://plugin.video.staycoolflix/live'})},
        {'label': 'Movies (demo)', 'path': build_url({'mode':'list', 'category':'movies'})},
        {'label': 'Settings', 'path': build_url({'mode':'settings'})},
    ]
    for it in items:
        li = xbmcgui.ListItem(it['label'])
        li.setArt({'icon': 'icon.png', 'thumb': 'icon.png'})
        xbmcplugin.addDirectoryItem(handle=_handle, url=it['path'], listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(_handle)

def list_movies():
    demo = [
        {'label':'Demo Movie 1', 'url':'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'},
        {'label':'Demo Movie 2', 'url':'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4'},
    ]
    for m in demo:
        li = xbmcgui.ListItem(m['label'])
        li.setInfo('video', {'title': m['label']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=_handle, url=m['url'], listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle)

def play(url):
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(_handle, True, li)

def router(paramstring):
    params = parse_qs(paramstring.lstrip('?'))
    mode = params.get('mode', [None])[0]
    if mode is None:
        list_root()
    elif mode == 'list':
        list_movies()
    elif mode == 'play':
        play(params.get('url', [''])[0])
    elif mode == 'settings':
        _addon.openSettings()
    else:
        list_root()

if __name__ == '__main__':
    router(sys.argv[2] if len(sys.argv) > 2 else '')
