# Placeholder for advanced player utilities (future)
def choose_stream(streams):
    # Example: choose highest bitrate
    return streams[0] if streams else None
