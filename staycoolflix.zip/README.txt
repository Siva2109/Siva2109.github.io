StayCoolFlix - Kodi plugin (demo)
---------------------------------
This is a minimal, ready-to-install Kodi video plugin template named 'StayCoolFlix'.
Features:
- Root menu with Live TV placeholder, Movies list and Settings.
- Demo playable sample videos (public sample videos).
- Small modern metadata in addon.xml.

How to install:
1. Download the staycoolflix.zip file.
2. In Kodi go to Add-ons -> Install from zip file -> select this zip.
3. Open Add-ons -> Video add-ons -> StayCoolFlix.

Expand this template by adding real streams, EPG, dynamic menus, artwork and settings.
